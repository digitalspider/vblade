import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import java.io.IOException;
import java.io.PrintWriter;
 
public class WifiServlet extends HttpServlet
{
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        System.out.println("request="+request);
        System.out.println("request.getPathInfo()="+request.getPathInfo());
        System.out.println("request.getServletPath()="+request.getServletPath());
        System.out.println("request.getQueryString()="+request.getQueryString());
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        response.setStatus(HttpServletResponse.SC_OK);
        out.println("<h1>Wifi Servlet</h1>");
        out.println("val="+request.getParameter("val")+"<br/>");
        out.println("session=" + request.getSession(true).getId());
    }
 
}
